
import SwiftUI

struct Child: Identifiable {
    var id = UUID()
    var name: String
    var dob: Date = Date() // Default to today's date
    var status: String
    var distance: Int
    var imageData: Data? // To store the raw image data (can be empty)
    var color: Color
    var zones: [Zone] = [] // Collection of zones associated with this child
    var notificationSettings: NotificationSettings = NotificationSettings()
}


