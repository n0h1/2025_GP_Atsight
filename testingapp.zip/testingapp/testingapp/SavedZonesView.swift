//
//  SavedZonesView.swift
//  testingapp
//
//  Created by MacBook Pro on 3/5/25.
//

import SwiftUI

struct SavedZonesView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct SavedZonesView_Previews: PreviewProvider {
    static var previews: some View {
        SavedZonesView()
    }
}
