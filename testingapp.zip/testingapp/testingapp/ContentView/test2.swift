////  test2.swift
////  testingapp
////
////  Created by MacBook Pro on 4/15/25.
////
//
//import SwiftUI
//
//struct test2: View {
//    // MARK: - ImagePicker Component:
//    struct ImagePicker: UIViewControllerRepresentable {
//        @Binding var selectedImage: UIImage?
//
//        class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
//            let parent: ImagePicker
//
//            init(_ parent: ImagePicker) {
//                self.parent = parent
//            }
//
//            func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
//                if let uiImage = info[.originalImage] as? UIImage {
//                    parent.selectedImage = uiImage
//                }
//
//                picker.dismiss(animated: true)
//            }
//        }
//
//        func makeCoordinator() -> Coordinator {
//            Coordinator(self)
//        }
//
//        func makeUIViewController(context: Context) -> UIImagePickerController {
//            let picker = UIImagePickerController()
//            picker.delegate = context.coordinator
//            return picker
//        }
//
//        func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {
//            // No updates needed
//        }
//    }
//
//    //MARK: Variables:
//
//
//    //MARK: Main View:
//    var body: some View {
//        VStack {
//
//        }
//    }
//}
//
//struct test2_Previews: PreviewProvider {
//    static let sampleChild = Child(id: UUID(), name: "Alice", dob: Date(), status: "Active", distance: 10, imageData: nil, color: .green)
//    static var previews: some View {
//        test2(child: sampleChild)
//    }
//
//}
