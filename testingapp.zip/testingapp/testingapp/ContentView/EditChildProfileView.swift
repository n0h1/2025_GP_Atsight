//update imageURL in the db (NEEDS STORAGE (SUBSCRIBTION))
//modify save changes button to update everything

import SwiftUI
import Firebase
import FirebaseFirestore
import FirebaseStorage

struct EditChildProfile: View {
    
    // MARK: - ImagePicker Component:
    struct ImagePicker: UIViewControllerRepresentable {
        @Binding var selectedImage: UIImage?
        
        class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
            let parent: ImagePicker
            
            init(_ parent: ImagePicker) {
                self.parent = parent
            }
            
            func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
                if let uiImage = info[.originalImage] as? UIImage {
                    parent.selectedImage = uiImage
                }
                
                picker.dismiss(animated: true)
            }
        }
        
        func makeCoordinator() -> Coordinator {
            Coordinator(self)
        }
        
        func makeUIViewController(context: Context) -> UIImagePickerController {
            let picker = UIImagePickerController()
            picker.delegate = context.coordinator
            return picker
        }
        
        func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {
            // No updates needed
        }
    }
    
    //MARK: Variables:
    @Binding var child: Child // Use @Binding to allow changes to propagate back
    
    // Added environment variable to dismiss view after save
    @Environment(\.presentationMode) var presentationMode

    // State variables to manage the image
    @State private var uiImage: UIImage?  // Holds the raw UIImage
    @State private var selectedImage: Image?  // Converted SwiftUI Image for display
    @State private var showingPhotoPicker = false  // Controls when to show the picker
    
    @State private var showingColorPicker = false
    let colors: [Color] = [.red, .green, .blue, .yellow, .orange, .purple, .pink, .brown, .gray]
    
    //MARK: Main View:
    var body: some View {
        VStack {
            
            //MARK: Child picture:
            VStack {
                // If child already has a profile picture:
                if let imageData = child.imageData, let uiImage = UIImage(data: imageData) {
                    Image(uiImage: uiImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 90, height: 90)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(.gray, lineWidth: 2))
                }
                
                //if user selected an image from album
                else if let selectedImage = selectedImage {
                    selectedImage
                        .resizable()
                        .scaledToFill()
                        .frame(width: 90, height: 90)
                        .clipShape(Circle())
                        .overlay(Circle().stroke(.gray, lineWidth: 2))
                }
                
                //otherwise: there is no profile picture
                else {
                    Image(systemName: "person.crop.circle.fill")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 90, height: 90)
                        .foregroundColor(.gray)
                    Text("add picture")
                        .font(.caption)
                        .foregroundColor(.gray)
                }
            }.padding(.bottom)
            
            //let user pick an image if he taps on the profile picture circle:
            .onTapGesture {
                showingPhotoPicker = true
            }
            .sheet(isPresented: $showingPhotoPicker) {
                ImagePicker(selectedImage: $uiImage)
            }
            .onChange(of: uiImage) { newValue in
                if let uiImage = uiImage {
                    selectedImage = Image(uiImage: uiImage)
                    child.imageData = uiImage.jpegData(compressionQuality: 0.8) // Update the child's imageData
                }
            }
            
            //MARK: Name, dob, and color data:
            Form {
            Section(header: Text("Name")) {
                TextField("Enter name", text: $child.name)
                    .textFieldStyle(.plain)
            }

            Section(header: Text("Date of Birth")) {
                DatePicker("Select Date", selection: $child.dob, displayedComponents: .date)
                    .datePickerStyle(CompactDatePickerStyle())
            }
                
                Section(header: Text("Color")) {
                    HStack {
                        Text("Color")
                        Spacer()
                        Rectangle().fill(child.color.opacity(0.7))
                            .frame(width: 30, height: 30)
                            .padding(.horizontal)
                    }
                }
                    .onTapGesture {
                        withAnimation {
                            showingColorPicker.toggle()
                        }
                    }
                
                //after clicking the "Color" field, display the row of colors for user to pick one for child:
                if showingColorPicker {
                    ScrollView(.horizontal) {
                        HStack {
                            ForEach(colors, id: \.self) { color in
                                Rectangle()
                                    .fill(color.opacity(0.7))
                                    .frame(width: 40, height: 40)
                                    .onTapGesture {
                                        print("Color selected: \(color)")
                                        child.color = color //update child's color for preview
                                        withAnimation {
                                            showingColorPicker = false // Optionally collapse after selection
                                        }
                                    }
                            }
                        }
                        .padding()
                    }
                    .transition(.move(edge: .bottom))
                }
                
                //MARK: Nanigations links:
                NavigationLink("Safe/Unsafe Zones Set-up", destination: AddZonePage(zones: $child.zones))
                NavigationLink("Location History", destination: LocationHistoryView())
                NavigationLink("Authorized People", destination: AuthorizedPeople())
                NavigationLink(destination: CustomizeNotifications(child: $child)) {
                    Text("Customize Notifications")
                }
            }//end form
            .background(Color(.systemBackground))
            
            //MARK: Save Changes Button:
            Button(action: {
                updateChildProfile()
            }) {
                Text("Save changes")
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color("Buttons").opacity(0.7))
                    .foregroundColor(.black)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
            }
            .padding()
            
            } //end vstack
        //top navigation bar
        .navigationBarBackButtonHidden(true)
                .navigationBarItems(leading:
                                        Button(action: { //navigate back
                    self.presentationMode.wrappedValue.dismiss()
                }) {
                    //navigate back button styling:
                    HStack {
                        Button(action: {
                            presentationMode.wrappedValue.dismiss()
                        }) {
                            Image(systemName: "chevron.left")
                                .foregroundColor(.black)
                                .font(.system(size: 20, weight: .bold))
                        }
                    }
                }
                )
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text("Edit Profile")
                    .font(.headline)
            }
        }//end toolbar
        
    } //no touch
    
    
    //MARK: functions:
    //function to save changes after editing child's profile
    func updateChildProfile() {
        // For testing purposes - hardcoded guardian ID
        let testGuardianID = "test-guardian-123"
        let childIDString = "4QU8xb7VN5CHAKLVnwDq" // Use the actual document ID
        
        print("Processing profile update for child: \(child.name)")
        
        // Check if we have image data to upload
        if let imageData = child.imageData {
            // Create a storage reference
            let storage = Storage.storage()
            let storageRef = storage.reference()
            let imageRef = storageRef.child("childImages/\(testGuardianID)/\(childIDString).jpg")
            
            // Show upload progress
            let uploadTask = imageRef.putData(imageData, metadata: nil) { (metadata, error) in
                if let error = error {
                    print("❌ Failed to upload image: \(error.localizedDescription)")
                    // Continue with update without image URL
                    self.saveToFirestore(guardianID: testGuardianID, childID: childIDString, imageURL: nil)
                    return
                }
                
                // Get download URL after successful upload
                imageRef.downloadURL { (url, error) in
                    if let error = error {
                        print("❌ Failed to get download URL: \(error.localizedDescription)")
                        self.saveToFirestore(guardianID: testGuardianID, childID: childIDString, imageURL: nil)
                        return
                    }
                    
                    // Save profile with image URL
                    if let downloadURL = url {
                        print("✅ Image uploaded with URL: \(downloadURL.absoluteString)")
                        self.saveToFirestore(guardianID: testGuardianID, childID: childIDString, imageURL: downloadURL.absoluteString)
                    } else {
                        self.saveToFirestore(guardianID: testGuardianID, childID: childIDString, imageURL: nil)
                    }
                }
            }
            
            // Monitor upload progress
            uploadTask.observe(.progress) { snapshot in
                if let progress = snapshot.progress {
                    let percentComplete = 100.0 * Double(progress.completedUnitCount) / Double(progress.totalUnitCount)
                    print("Upload is \(percentComplete)% complete")
                }
            }
        } else {
            // No image data to upload, just update the profile
            saveToFirestore(guardianID: testGuardianID, childID: childIDString, imageURL: nil)
        }
    }

    // Separate function to handle the Firestore update
    private func saveToFirestore(guardianID: String, childID: String, imageURL: String?) {
        print("Saving to Firestore for child: \(child.name)")
        
        let db = Firestore.firestore()
        let childDocRef = db.collection("guardians").document(guardianID).collection("children").document(childID)
        
        // Create base data dictionary
        var updatedData: [String: Any] = [
            "name": child.name,
            "color": colorToString(child.color)
        ]
        
        // Add DOB as Timestamp
        let dobTimestamp = Timestamp(date: child.dob)
        updatedData["dob"] = dobTimestamp
        
        // Add imageURL if available
        if let imageURL = imageURL {
            updatedData["imageURL"] = imageURL
            print("Including imageURL in update: \(imageURL)")
        }
        
        print("Firestore update data: \(updatedData)")
        
        // Update Firestore
        childDocRef.updateData(updatedData) { error in
            if let error = error {
                print("❌ Failed to update child profile: \(error.localizedDescription)")
            } else {
                print("✅ Successfully updated child profile with all data")
            }
            
            // Navigate back regardless of success/failure
            DispatchQueue.main.async {
                self.presentationMode.wrappedValue.dismiss()
            }
        }
    }
    
    // Main function that handles the Firestore update
    func updateChildProfile(guardianID: String, childID: String, updatedChild: Child, completion: @escaping (Result<Void, Error>) -> Void) {
        let db = Firestore.firestore()
        
        // Reference to the specific child document
        let childDocRef = db.collection("guardians").document(guardianID).collection("children").document(childID)
        
        // Create a dictionary for the Firebase update
        var updatedData: [String: Any] = [
            "name": updatedChild.name,
            "color": colorToString(updatedChild.color) // Convert Color to String for Firebase
        ]
        
        // Add DOB as Timestamp for Firebase
        let dobTimestamp = Timestamp(date: updatedChild.dob)
        updatedData["dob"] = dobTimestamp
        
        // Add imageData if available
        if let imageData = updatedChild.imageData {
            updatedData["imageData"] = imageData
        }
        
        // Update the document
        childDocRef.updateData(updatedData) { error in
            if let error = error {
                print("❌ Failed to update child profile: \(error.localizedDescription)")
                completion(.failure(error))
            } else {
                print("✅ Successfully updated child profile for /guardians/\(guardianID)/children/\(childID)")
                completion(.success(()))
            }
        }
    }
    
    // Helper function to convert Color to String for Firebase storage
    private func colorToString(_ color: Color) -> String {
        if color == .red { return "Red" }
        else if color == .green { return "Green" }
        else if color == .blue { return "Blue" }
        else if color == .yellow { return "Yellow" }
        else if color == .orange { return "Orange" }
        else if color == .purple { return "Purple" }
        else if color == .pink { return "Pink" }
        else if color == .brown { return "Brown" }
        else if color == .gray { return "Gray" }
        else { return "Gray" } // Default color
    }
    
    //MARK: Image upload function
    func uploadImageAndUpdateProfile(imageData: Data) {
        // For testing purposes - hardcoded guardian ID
        let testGuardianID = "test-guardian-123"
        let childIDString = "4QU8xb7VN5CHAKLVnwDq" // Use the actual document ID
        
        print("Uploading image for child: \(child.name)")
        
        // Create a storage reference
        let storage = Storage.storage()
        let storageRef = storage.reference()
        let imageRef = storageRef.child("childImages/\(testGuardianID)/\(childIDString).jpg")
        
        // Upload the image data
        let uploadTask = imageRef.putData(imageData, metadata: nil) { (metadata, error) in
            if let error = error {
                print("❌ Failed to upload image: \(error.localizedDescription)")
                // Fall back to just updating the profile without the image
                self.updateChildProfile()
                return
            }
            
            // Image uploaded successfully, now get the download URL
            imageRef.downloadURL { (url, error) in
                if let error = error {
                    print("❌ Failed to get download URL: \(error.localizedDescription)")
                    // Fall back to just updating the profile without the image URL
                    self.updateChildProfile()
                    return
                }
                
                guard let downloadURL = url else {
                    print("❌ Download URL is nil")
                    self.updateChildProfile()
                    return
                }
                
                print("✅ Image uploaded successfully with URL: \(downloadURL.absoluteString)")
                
                // Now update the profile with the image URL
                self.updateChildProfile(imageURL: downloadURL.absoluteString)
            }
        }
        
        // Handle upload progress if needed
        uploadTask.observe(.progress) { snapshot in
            let percentComplete = 100.0 * Double(snapshot.progress!.completedUnitCount) / Double(snapshot.progress!.totalUnitCount)
            print("Upload is \(percentComplete)% complete")
        }
    }

    //function to save changes after editing child's profile with optional imageURL
    func updateChildProfile(imageURL: String? = nil) {
        // For testing purposes - hardcoded guardian ID
        let testGuardianID = "test-guardian-123"
        let childIDString = "4QU8xb7VN5CHAKLVnwDq" // Use the actual document ID
        
        print("Saving changes for child: \(child.name)")
        
        // Update Firestore with the changes
        let db = Firestore.firestore()
        let childDocRef = db.collection("guardians").document(testGuardianID).collection("children").document(childIDString)
        
        // Data to update
        var updatedData: [String: Any] = [
            "name": child.name,
            "color": colorToString(child.color)
        ]
        
        // Add DOB as Timestamp for Firebase
        let dobTimestamp = Timestamp(date: child.dob)
        updatedData["dob"] = dobTimestamp
        
        // Add imageURL if available
        if let imageURL = imageURL {
            updatedData["imageURL"] = imageURL
        }
        
        print("Updating with data: \(updatedData)")
        
        // Update the document
        childDocRef.updateData(updatedData) { error in
            if let error = error {
                print("❌ Failed to update child profile: \(error.localizedDescription)")
            } else {
                print("✅ Successfully updated child profile")
            }
            
            // Navigate back to previous screen
            DispatchQueue.main.async {
                self.presentationMode.wrappedValue.dismiss()
            }
        }
    }
    
    
    
}


struct EditChildProfile_Previews: PreviewProvider {
    // For your preview:
    static let sampleChild = Child(id: UUID(), name: "Alice", dob: Date(), status: "Active", distance: 10, imageData: nil, color: .green)
    static var previews: some View {
        EditChildProfile(child: .constant(sampleChild))
    }
}
