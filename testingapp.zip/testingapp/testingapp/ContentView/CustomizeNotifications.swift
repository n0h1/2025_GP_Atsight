import SwiftUI
import Firebase
import FirebaseFirestore
import AVFoundation

// MARK: - Sound Player
class SoundPlayer {
    static let shared = SoundPlayer()
    private var audioPlayer: AVAudioPlayer?
    
    func playSound(named soundName: String) {
        guard let url = Bundle.main.url(forResource: soundName, withExtension: "wav") else {
            print("Sound file not found")
            return
        }
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: url)
            audioPlayer?.play()
        } catch {
            print("Failed to play sound: \(error)")
        }
    }
}

// MARK: - Notification Sound Options
enum NotificationSound: String, CaseIterable, Identifiable {
    case defaultSound = "Default"
    case alert = "Alert"
    case bell = "Bell"
    case chime = "Chime"
    case chirp = "Chirp"
    
    var id: String { self.rawValue }
    
    var filename: String {
        switch self {
        case .defaultSound: return "default_sound"
        case .alert: return "alert_sound"
        case .bell: return "bell_sound"
        case .chime: return "chime_sound"
        case .chirp: return "chirp_sound"
        }
    }
    
    static func fromString(_ string: String) -> NotificationSound {
        return NotificationSound.allCases.first { $0.filename == string } ?? .defaultSound
    }
}

// MARK: NotificationSettings Struct:
struct NotificationSettings: Codable, Equatable {
    var safeZoneAlert: Bool = true
    var unsafeZoneAlert: Bool = true
    var lowBatteryAlert: Bool = true
    var watchRemovedAlert: Bool = true
    var newAuthorAccount: Bool = true
    var sound: String = "default_sound" //default sound asset
}


// MARK: Variables:
struct CustomizeNotifications: View {
    @Environment(\.presentationMode) var presentationMode
    
    // Binding to the child object passed from EditChildProfile
    @Binding var child: Child
    
    // State variables for toggle switches, initialized from child
    @State private var safeZoneAlert: Bool
    @State private var unsafeZoneAlert: Bool
    @State private var lowBatteryAlert: Bool
    @State private var watchRemovedAlert: Bool
    @State private var newAuthorAccount: Bool
    
    // State variables for notification sound selection
    @State private var showSoundPicker = false
    @State private var selectedSound: NotificationSound
    
    // Loading state
    @State private var isLoading = false
    
    // Initialize state variables from child's notification settings
    init(child: Binding<Child>) {
        self._child = child
        let settings = child.wrappedValue.notificationSettings
        
        _safeZoneAlert = State(initialValue: settings.safeZoneAlert)
        _unsafeZoneAlert = State(initialValue: settings.unsafeZoneAlert)
        _lowBatteryAlert = State(initialValue: settings.lowBatteryAlert)
        _watchRemovedAlert = State(initialValue: settings.watchRemovedAlert)
        _newAuthorAccount = State(initialValue: settings.newAuthorAccount)
        _selectedSound = State(initialValue: NotificationSound.fromString(settings.sound))
    }
    
    // MARK: Main View:
    var body: some View {
        VStack(spacing: 16) {
            Text("Type of Notifications").font(.title).foregroundColor(.gray).frame(maxWidth: .infinity , alignment: .leading)
            
            // Safe zone alerts:
            HStack {
                Image(systemName: "bell").resizable()
                    .scaledToFill()
                    .frame(width: 30, height: 30).padding(20)
                
                VStack(alignment: .leading) {
                    Text("Safe zone alert").fontWeight(.bold)
                    Text("alert in case child is out of a safe zone").foregroundColor(.gray.opacity(0.7))
                }.frame(maxWidth: .infinity, alignment: .leading)
                
                Toggle("", isOn: $safeZoneAlert)
                    .toggleStyle(SwitchToggleStyle(tint: .mint))
                    .labelsHidden().padding()
                    .onChange(of: safeZoneAlert) { newValue in
                        // Just update the local child object
                        child.notificationSettings.safeZoneAlert = newValue
                    }
            }
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.white)
                    .shadow(color: Color.gray.opacity(0.3), radius: 8, x: 0, y: 2)
            )
            
            // Unsafe zone alerts:
            HStack {
                Image(systemName: "bell").resizable()
                    .scaledToFill()
                    .frame(width: 30, height: 30).padding(20)
                
                VStack(alignment: .leading) {
                    Text("Unsafe zone alert").fontWeight(.bold)
                    Text("alert in case child is near an unsafe zone").foregroundColor(.gray.opacity(0.7))
                }.frame(maxWidth: .infinity, alignment: .leading)
                
                Toggle("", isOn: $unsafeZoneAlert)
                    .toggleStyle(SwitchToggleStyle(tint: .mint))
                    .labelsHidden().padding()
                    .onChange(of: unsafeZoneAlert) { newValue in
                        child.notificationSettings.unsafeZoneAlert = newValue
                    }
            }
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.white)
                    .shadow(color: Color.gray.opacity(0.3), radius: 8, x: 0, y: 2)
            )
            
            // Low battery alerts:
            HStack {
                Image(systemName: "bell").resizable()
                    .scaledToFill()
                    .frame(width: 30, height: 30).padding(20)
                
                VStack(alignment: .leading) {
                    Text("Low Battery alert").fontWeight(.bold)
                    Text("alert if watch is low on battery").foregroundColor(.gray.opacity(0.7))
                }.frame(maxWidth: .infinity, alignment: .leading)
                
                Toggle("", isOn: $lowBatteryAlert)
                    .toggleStyle(SwitchToggleStyle(tint: .mint))
                    .labelsHidden().padding()
                    .onChange(of: lowBatteryAlert) { newValue in
                        child.notificationSettings.lowBatteryAlert = newValue
                    }
            }
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.white)
                    .shadow(color: Color.gray.opacity(0.3), radius: 8, x: 0, y: 2)
            )
            
            // Watch removal alerts:
            HStack {
                Image(systemName: "bell").resizable()
                    .scaledToFill()
                    .frame(width: 30, height: 30).padding(20)
                
                VStack(alignment: .leading) {
                    Text("Watch Removed Alert").fontWeight(.bold)
                    Text("alert if child removed the watch").foregroundColor(.gray.opacity(0.7))
                }.frame(maxWidth: .infinity, alignment: .leading)
                
                Toggle("", isOn: $watchRemovedAlert)
                    .toggleStyle(SwitchToggleStyle(tint: .mint))
                    .labelsHidden().padding()
                    .onChange(of: watchRemovedAlert) { newValue in
                        child.notificationSettings.watchRemovedAlert = newValue
                    }
            }
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.white)
                    .shadow(color: Color.gray.opacity(0.3), radius: 8, x: 0, y: 2)
            )
            
            // New Author account alert:
            HStack {
                Image(systemName: "bell").resizable()
                    .scaledToFill()
                    .frame(width: 30, height: 30).padding(20)
                
                VStack(alignment: .leading) {
                    Text("New Author Account").fontWeight(.bold)
                    Text("alert if child profile has been accessed").foregroundColor(.gray.opacity(0.7))
                }.frame(maxWidth: .infinity, alignment: .leading)
                
                Toggle("", isOn: $newAuthorAccount)
                    .toggleStyle(SwitchToggleStyle(tint: .mint))
                    .labelsHidden().padding()
                    .onChange(of: newAuthorAccount) { newValue in
                        child.notificationSettings.newAuthorAccount = newValue
                    }
            }
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.white)
                    .shadow(color: Color.gray.opacity(0.3), radius: 8, x: 0, y: 2)
            )
            
            // Selecting specific notification sound for the child:
            HStack {
                Image(systemName: "speaker.wave.2").resizable()
                    .scaledToFill()
                    .frame(width: 30, height: 30).padding(20)
                
                VStack(alignment: .leading) {
                    Text("Notification Sound").fontWeight(.bold)
                    Text("choose sound for all notifications").foregroundColor(.gray.opacity(0.7))
                }.frame(maxWidth: .infinity, alignment: .leading)
                
                Button(action: {
                    showSoundPicker = true
                }) {
                    HStack {
                        Text(selectedSound.rawValue)
                            .foregroundColor(.primary)
                        Image(systemName: "chevron.right")
                            .foregroundColor(.gray)
                    }
                    .padding(.horizontal, 12)
                    .padding(.vertical, 8)
                    .background(Color.gray.opacity(0.1))
                    .cornerRadius(8)
                }
                .padding()
            }
            .background(
                RoundedRectangle(cornerRadius: 10)
                    .fill(Color.white)
                    .shadow(color: Color.gray.opacity(0.3), radius: 8, x: 0, y: 2)
            )
            
            // Loading indicator
            if isLoading {
                ProgressView("Updating settings...")
                    .padding()
            }
            
            Spacer()
            
        }
        .padding()
        .sheet(isPresented: $showSoundPicker) {
            NotificationSoundPicker(selectedSound: $selectedSound, onSoundSelected: { sound in
                // Just update the local child object
                child.notificationSettings.sound = sound.filename
            })
        }
        
        // Top navigation bar
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(
            leading: Button(action: {
                self.presentationMode.wrappedValue.dismiss()
            }) {
                Image(systemName: "chevron.left")
                    .foregroundColor(.black)
                    .font(.system(size: 20, weight: .bold))
            },
            trailing: Button(action: {
                saveAllNotificationSettings()
            }) {
                Text("Done")
                    .foregroundColor(Color("TextColor"))
                    .fontWeight(.bold)
            }
        )
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text("Customize Notifications")
                    .font(.headline)
            }
        }
    }
    
    // Function to save all notification settings at once
    private func saveAllNotificationSettings() {
        isLoading = true
        
        let db = Firestore.firestore()
        
        // Using your hardcoded IDs for testing
        let guardianID = "test-guardian-123"
        let childDocID = "4QU8xb7VN5CHAKLVnwDq" // Using your actual document ID instead of child.id.uuidString
        let notificationDocID = "BaOwvWw8CoR9WdErQRXG"
        
        // Reference to the specific notification document
        let notificationDocRef = db.collection("guardians").document(guardianID)
            .collection("children").document(childDocID)
            .collection("notifications").document(notificationDocID)
        
        // Create a dictionary with all notification settings
        let notificationSettings: [String: Any] = [
            "safeZoneAlert": safeZoneAlert,
            "unsafeZoneAlert": unsafeZoneAlert,
            "lowBatteryAlert": lowBatteryAlert,
            "watchRemovedAlert": watchRemovedAlert,
            "newAuthorAccount": newAuthorAccount,
            "sound": selectedSound.filename
        ]
        
        // Update both the local model and Firestore
        child.notificationSettings = NotificationSettings(
            safeZoneAlert: safeZoneAlert,
            unsafeZoneAlert: unsafeZoneAlert,
            lowBatteryAlert: lowBatteryAlert,
            watchRemovedAlert: watchRemovedAlert,
            newAuthorAccount: newAuthorAccount,
            sound: selectedSound.filename
        )
        
        // Update the Firestore document
        notificationDocRef.setData(notificationSettings, merge: true) { error in
            DispatchQueue.main.async {
                isLoading = false
                
                if let error = error {
                    print("❌ Error updating notification settings: \(error.localizedDescription)")
                } else {
                    print("✅ Successfully updated all notification settings")
                    self.presentationMode.wrappedValue.dismiss()
                }
            }
        }
    }
}

// MARK: - Sound Picker View
struct NotificationSoundPicker: View {
    @Binding var selectedSound: NotificationSound
    var onSoundSelected: (NotificationSound) -> Void
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            List {
                ForEach(NotificationSound.allCases) { sound in
                    HStack {
                        Text(sound.rawValue)
                        Spacer()
                        if selectedSound == sound {
                            Image(systemName: "checkmark")
                                .foregroundColor(.mint)
                        }
                    }
                    .contentShape(Rectangle())
                    .onTapGesture {
                        selectedSound = sound
                        SoundPlayer.shared.playSound(named: sound.filename)
                        onSoundSelected(sound)
                    }
                    .padding(.vertical, 8)
                }
            }
            .navigationTitle("Select Sound")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .navigationBarLeading) {
                    Button("Cancel") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
                
                ToolbarItem(placement: .navigationBarTrailing) {
                    Button("Done") {
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct CustomizeNotifications_Previews: PreviewProvider {
    static var previews: some View {
        // Create a sample child for preview
        let sampleChild = Child(
            id: UUID(),
            name: "Test Child",
            dob: Date(),
            status: "Active",
            distance: 10,
            imageData: nil,
            color: .blue
        )
        
        return CustomizeNotifications(child: .constant(sampleChild))
    }
}
