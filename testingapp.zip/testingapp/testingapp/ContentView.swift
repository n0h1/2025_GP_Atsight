//remove fixed child refernece
import SwiftUI
import Firebase
import FirebaseFirestore
import MapKit

struct ContentView: View {

    //MARK: Variables:
    @State private var editableChild = Child(
        id: UUID(uuidString: "4QU8xb7VN5CHAKLVnwDq") ?? UUID(),
        name: "Loading...",
        dob: Date(),
        status: "Active",
        distance: 10,
        imageData: nil,
        color: .blue
    )

    @State private var isLoading = true

    //MARK: Main App:
    var body: some View {
        NavigationView {
            ZStack {
                EditChildProfile(child: $editableChild)
                    .onAppear {
                        // Fetch the child data when view appears
                        fetchChildData()
                    }

                if isLoading {
                    ProgressView("Loading child data...")
                        .padding()
                        .background(Color.white.opacity(0.9))
                        .cornerRadius(10)
                }
            }
            .navigationTitle("")
            .navigationBarBackButtonHidden(true)
        }
    }
    

    //MARK: Fetching Child Data:
    func fetchChildData() {
        let db = Firestore.firestore()
        let testGuardianID = "test-guardian-123"
        let childDocID = "4QU8xb7VN5CHAKLVnwDq"
        
        // Reference to the main child document
        let childRef = db.collection("guardians").document(testGuardianID).collection("children").document(childDocID)
        
        // First fetch the child document
        childRef.getDocument { snapshot, error in
            if let error = error {
                print("❌ Error fetching child: \(error.localizedDescription)")
                isLoading = false
                return
            }
            
            guard let data = snapshot?.data() else {
                print("❌ No child data found")
                isLoading = false
                return
            }
            
            print("✅ Child data retrieved: \(data)")
            
            // Update the child object with basic data
            if let name = data["name"] as? String {
                editableChild.name = name
            }
            
            if let dobTimestamp = data["dob"] as? Timestamp {
                editableChild.dob = dobTimestamp.dateValue()
            }
            
            if let colorString = data["color"] as? String {
                editableChild.color = getColor(from: colorString)
            }
            
            if let status = data["status"] as? String {
                editableChild.status = status
            }
            
            if let distance = data["distance"] as? Int {
                editableChild.distance = distance
            }
            
            if let imageURLString = data["imageURL"] as? String, let imageURL = URL(string: imageURLString) {
                URLSession.shared.dataTask(with: imageURL) { (data, response, error) in
                    if let imageData = data {
                        DispatchQueue.main.async {
                            editableChild.imageData = imageData
                        }
                    }
                }.resume()
            }
        
            // Fetch notification document
            childRef.collection("notifications").document("BaOwvWw8CoR9WdErQRXG").getDocument { (notificationsSnapshot, notificationsError) in
                if let notificationsError = notificationsError {
                    print("❌ Error fetching notification: \(notificationsError.localizedDescription)")
                } else if let notificationsData = notificationsSnapshot?.data() {
                    var notificationSettings = NotificationSettings()
                    
                    if let safeZoneAlert = notificationsData["safeZoneAlert"] as? Bool {
                        notificationSettings.safeZoneAlert = safeZoneAlert
                    }
                    if let unsafeZoneAlert = notificationsData["unsafeZoneAlert"] as? Bool {
                        notificationSettings.unsafeZoneAlert = unsafeZoneAlert
                    }
                    if let lowBatteryAlert = notificationsData["lowBatteryAlert"] as? Bool {
                        notificationSettings.lowBatteryAlert = lowBatteryAlert
                    }
                    if let watchRemovedAlert = notificationsData["watchRemovedAlert"] as? Bool {
                        notificationSettings.watchRemovedAlert = watchRemovedAlert
                    }
                    if let newAuthorAccount = notificationsData["newAuthorAccount"] as? Bool {
                        notificationSettings.newAuthorAccount = newAuthorAccount
                    }
                    if let sound = notificationsData["sound"] as? String {
                        notificationSettings.sound = sound  // Assuming you fixed the typo in the struct
                    }
                    
                    editableChild.notificationSettings = notificationSettings
                    print("✅ Notification settings loaded")
                }
                
                // Fetch zones
                childRef.collection("zones").getDocuments { (zonesSnapshot, zonesError) in
                    if let zonesError = zonesError {
                        print("❌ Error fetching zones: \(zonesError.localizedDescription)")
                        isLoading = false
                        return
                    }
                    
                    print("Found \(zonesSnapshot?.documents.count ?? 0) zone documents")
                    var zones: [Zone] = []
                    
                    for document in zonesSnapshot?.documents ?? [] {
                        let data = document.data()
                        print("Zone document ID: \(document.documentID), data: \(data)")
                        
                        // Check if coordinate is a GeoPoint
                        if let geoPoint = data["coordinate"] as? GeoPoint,
                           let zoneName = data["zoneName"] as? String,
                           let isSafeZone = data["isSafeZone"] as? Bool,
                           let zoneSize = data["zoneSize"] as? Double {
                            
                            let coordinate = CLLocationCoordinate2D(latitude: geoPoint.latitude, longitude: geoPoint.longitude)
                            let zone = Zone(
                                coordinate: coordinate,
                                zoneName: zoneName,
                                isSafeZone: isSafeZone,
                                zoneSize: zoneSize
                            )
                            zones.append(zone)
                            print("Added zone: \(zoneName)")
                        } else {
                            print("❌ Failed to parse zone data: \(data)")
                        }
                    }
                    
                    editableChild.zones = zones
                    print("✅ zones loaded: \(zones.count)")
                    isLoading = false
                }
            }
        }
    }

    // Helper function to convert string to Color
    private func getColor(from colorName: String) -> Color {
        switch colorName {
        case "Red": return .red
        case "Green": return .green
        case "Blue": return .blue
        case "Yellow": return .yellow
        case "Orange": return .orange
        case "Purple": return .purple
        case "Pink": return .pink
        case "Brown": return .brown
        case "Gray": return .gray
        default: return .gray
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
