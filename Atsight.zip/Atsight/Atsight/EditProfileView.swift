//
//  EditProfileView.swift
//  AtSightSprint0Test
//
//  Created by Najd Alsabi on 13/02/2025.
//

import SwiftUI

// ✅ Ensure `AddZonePage` is recognized
import FirebaseAuth
import FirebaseFirestore

struct EditProfileView: View {
    @State private var name: String = "Melissa Peters"
    @State private var birthDate: Date = Date()
    @Environment(\.presentationMode) var presentationMode
    
    var body: some View {
        NavigationView {
            VStack {
                HStack {
                    Button(action: {
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                            .font(.system(size: 20, weight: .bold))
                    }
                    
                    Spacer()
                    
                    Text("Edit Profile")
                        .font(.title2)
                        .bold()
                    
                    Spacer()
                    
                    Spacer().frame(width: 24) // Balancing layout
                }
                .padding()
                
                Spacer()
                ProfileImageView()
                Form {
                    Section(header: Text("Name")) {
                        TextField("Enter name", text: $name)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                    }.padding(.bottom, -40)
                    
                    Section(header: Text("Date of Birth")) {
                        DatePicker("Select Date", selection: $birthDate, displayedComponents: .date)
                            .datePickerStyle(CompactDatePickerStyle())
                    }

                    // ✅ Ensure AddZonePage is recognized
                    NavigationLink("Safe/Unsafe Zones Set-up", destination: AddZonePage())

                    NavigationLink("Location History", destination: LocationHistoryView())
                    NavigationLink("Authorized People", destination: Text("Authorized People View"))
                    NavigationLink("Customize Notifications", destination: Text("Notifications View"))
                }
                .scrollContentBackground(.hidden) // Keeps background consistent
                .background(Color(.systemBackground))
                
                Button(action: {
                    // Save action
                }) {
                    Text("Save changes")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color("Buttons").opacity(0.7))
                        .foregroundColor(.black)
                        .clipShape(RoundedRectangle(cornerRadius: 10))
                }
                .padding()
            }
        }
        .navigationBarHidden(true)
        .navigationBarBackButtonHidden(true)
    }
}

// Profile Image View
struct ProfileImageView: View {
    var body: some View {
        VStack {
            VStack {
                Image(systemName: "person.crop.circle.fill")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 90, height: 90)
                    .foregroundColor(.gray)
                Text("add picture")
                    .font(.caption)
                    .foregroundColor(.gray)
            }
        }
        .padding()
    }
}

struct Previews: PreviewProvider {
    static var previews: some View {
        EditProfileView()
    }
}
