//
//  ModelsChild..swift
//  AtSightSprint0Test
//
//  Created by Najd Alsabi on 13/02/2025.
//
import SwiftUI

struct Child: Identifiable, Equatable {
    var id = UUID()
    var name: String
    var status: String
    var distance: Int
    var color: Color
}
