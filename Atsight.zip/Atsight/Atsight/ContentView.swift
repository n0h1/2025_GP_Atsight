//
//  ContentView.swift
//  Atsight
//
//  Created by lona on 28/01/2025.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        NavigationView {
            ZStack {
                Color("CustomBackground")
                    .edgesIgnoringSafeArea(.all)

                VStack {
                    Spacer()

                    Image("logo")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 340)
                        .padding()

                    Spacer()
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)

                // Full-screen transparent button to navigate
                NavigationLink(destination: WelcomePage1()) {
                    Color.clear // Transparent overlay
                }
                .frame(maxWidth: .infinity, maxHeight: .infinity)
            }
            .navigationBarHidden(true) // Hide top navigation bar
        }
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

#Preview {
    ContentView()
}
