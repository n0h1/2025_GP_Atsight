import SwiftUI
import FirebaseAuth // ✅ Import for Firebase Authentication
import FirebaseFirestore // ✅ Import for Firestore

struct SignUpPage: View {
    @State private var isTermsAccepted = false // Track the state of the checkbox
    @State private var firstName = ""
    @State private var lastName = ""
    @State private var email = ""
    @State private var password = ""
    @State private var errorMessage = "" // State for displaying error messages
    @State private var isRegistered = false // ✅ Track registration success

    var body: some View {
        NavigationView {
            VStack(spacing: 10) {
                HStack {
                    Image("logotext")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 100)
                    Spacer()
                }
                .padding(.horizontal, 20)
                .padding(.top, -20)

                VStack(spacing: 5) {
                    Image("logoPin")
                        .resizable()
                        .scaledToFit()
                        .frame(height: 200)
                    Text("Get Started")
                        .font(.largeTitle)
                        .fontWeight(.bold)
                        .foregroundColor(Color("FontColor"))
                    Text("By Creating an account")
                        .font(.subheadline)
                        .foregroundColor(.gray)
                }

                VStack(spacing: 15) {
                    TextField("First Name", text: $firstName)
                        .padding()
                        .background(Color.gray.opacity(0.2))
                        .cornerRadius(50)
                    TextField("Last Name", text: $lastName)
                        .padding()
                        .background(Color.gray.opacity(0.2))
                        .cornerRadius(50)
                    TextField("Valid email", text: $email)
                        .padding()
                        .background(Color.gray.opacity(0.2))
                        .cornerRadius(50)
                    SecureField("Strong Password", text: $password)
                        .padding()
                        .background(Color.gray.opacity(0.2))
                        .cornerRadius(50)
                }
                .padding(.horizontal, 20)

                if !errorMessage.isEmpty {
                    Text(errorMessage)
                        .foregroundColor(.red)
                        .padding()
                        .background(Color.red.opacity(0.1))
                        .cornerRadius(10)
                }

                Button(action: {
                    register()
                }) {
                    Text("Get Started")
                        .font(.headline)
                        .foregroundColor(.black)
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color("button"))
                        .cornerRadius(10)
                }
                .padding(.horizontal, 40)
                .padding(.top, 10)

                HStack {
                    Text("Do you have an account?")
                    NavigationLink(destination: LoginPage()) {
                        Text("Sign In")
                            .foregroundColor(.blue)
                            .underline()
                    }
                }
                Spacer()
            }
            .padding()
            .background(Color("CustomBackground").edgesIgnoringSafeArea(.all))
            .navigationBarBackButtonHidden(true)
            .fullScreenCover(isPresented: $isRegistered) { // ✅ Navigate to HomeView after successful registration
                HomeView(selectedChild: .constant(nil), expandedChild: .constant(nil))
            }
        }
    }

    // ✅ Updated register function to save ID inside '/guardians' and add required collections
    func register() {
        let db = Firestore.firestore()
        let guardiansCollection = db.collection("guardians")
        
        // Fetch current count to generate next guardian ID
        guardiansCollection.getDocuments { snapshot, error in
            if let error = error {
                errorMessage = "Error fetching guardians: \(error.localizedDescription)"
                return
            }

            // Get the highest existing numeric ID
            let maxID = snapshot?.documents.compactMap { Int($0.documentID) }.max() ?? 0
            let newGuardianID = maxID + 1 // Generate the next ID
            
            Auth.auth().createUser(withEmail: email, password: password) { result, error in
                if let error = error {
                    errorMessage = error.localizedDescription
                    return
                }

                let guardianRef = guardiansCollection.document("\(newGuardianID)") // ✅ Use numeric ID
                
                let guardianData: [String: Any] = [
                    "uid": result?.user.uid ?? "",
                    "FirstName": firstName,
                    "LastName": lastName,
                    "email": email,
                    "phonenum": "",
                    "region": [0.0, 0.0]
                ]

                guardianRef.setData(guardianData) { error in
                    if let error = error {
                        errorMessage = "Failed to save user data: \(error.localizedDescription)"
                    } else {
                        // ✅ Create required sub-collections
                        guardianRef.collection("children").document().setData([:])
                        guardianRef.collection("connectedGuardians").document().setData([:])
                        
                        isRegistered = true // Navigate to HomeView
                    }
                }
            }
        }
    }

}

#Preview {
    SignUpPage()
}
