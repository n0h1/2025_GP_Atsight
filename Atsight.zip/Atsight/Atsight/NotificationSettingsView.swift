//
//  NotificationSettingsView.swift
//  Atsight
//
//  Created by lona on 26/02/2025.
//


import SwiftUI

struct NotificationSettingsView: View {
    @State private var safeZoneAlert = false
    @State private var unsafeZoneAlert = false
    @State private var batteryLow = false
    @State private var movement = false
    @State private var watchRemoved = false
    @State private var newAuthorAccount = false
    
    var body: some View {
        NavigationView {
            VStack {
                List {
                    NotificationToggle(title: "Safe Zone Alert", description: "Alert in case child out of safe zone", isOn: $safeZoneAlert)
                    NotificationToggle(title: "Unsafe Zone Alert", description: "Alert in case child near unsafe zone", isOn: $unsafeZoneAlert)
                    NotificationToggle(title: "Battery Low", description: "Alert if watch is low battery", isOn: $batteryLow)
                    NotificationToggle(title: "Movement", description: "Alert for each movement", isOn: $movement)
                    NotificationToggle(title: "Watch Removed or Alert", description: "Alert if child removed the watch", isOn: $watchRemoved)
                    NotificationToggle(title: "New Author Account", description: "Alert if child profile has been accessed", isOn: $newAuthorAccount)
                }
                .listStyle(PlainListStyle())
            }
            .navigationTitle("Customize Notifications")
        }
    }
}

struct NotificationToggle: View {
    let title: String
    let description: String
    @Binding var isOn: Bool
    
    var body: some View {
        HStack {
            Image(systemName: "bell")
                .foregroundColor(.black)
                .padding(.trailing, 10)
            VStack(alignment: .leading) {
                Text(title)
                    .font(.headline)
                Text(description)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            Spacer()
            Toggle("", isOn: $isOn)
                .labelsHidden()
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(30)
        .shadow(radius: 1)
    }
}

struct NotificationSettingsView_Previews: PreviewProvider {
    static var previews: some View {
        NotificationSettingsView()
    }
}
