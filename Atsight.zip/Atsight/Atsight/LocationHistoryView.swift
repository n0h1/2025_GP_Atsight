//
//  LocationHistoryView.swift
//  Atsight
//
//  Updated to fix iOS 16 & 17 deprecations
//

import SwiftUI
import MapKit

struct LocationHistoryView: View {
    let locations = [
        Location(name: "Office", address: "2972 Westheimer Rd, Santa Ana, Illinois", date: "2025/2/16", time: "11:37 AM", distance: "2.7km", latitude: 33.7488, longitude: -84.3877),
        Location(name: "Coffee Shop", address: "1901 Thornridge Cir, Shiloh, Hawaii", date: "2025/2/12", time: "1:30 PM", distance: "1.1km", latitude: 21.3099, longitude: -157.8581),
        Location(name: "Shopping Center", address: "4140 Parker Rd, Allentown, New Mexico", date: "2025/2/10", time: "5:00 PM", distance: "4.9km", latitude: 35.0844, longitude: -106.6504),
        Location(name: "School", address: "4140 Parker Rd, Allentown, New Mexico", date: "2025/2/9", time: "9:20 AM", distance: "3km", latitude: 40.7128, longitude: -74.0060)
    ]

    @State private var selectedLocation: Location?

    var body: some View {
        NavigationStack {
            VStack {
                // Header with Back Button and Title
                HStack {
                    Button(action: {
                        selectedLocation = nil
                    }) {
                        Image(systemName: "chevron.left")
                            .foregroundColor(.black)
                            .font(.system(size: 20, weight: .bold))
                    }

                    Spacer()

                    Text("Location History")
                        .font(.title2)
                        .bold()

                    Spacer()
                }
                .padding()

                // Recent Places Title
                Text("Recent Places")
                    .foregroundColor(Color(red: 90/255, green: 90/255, blue: 90/255))
                    .bold()
                    .font(.headline)
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(.leading, 20)
                    .padding(.top, 40)
                    .padding(.bottom, 10)

                // Scrollable List with Navigation
                ScrollView {
                    VStack(spacing: 14) {
                        ForEach(locations) { location in
                            NavigationLink(value: location) {
                                LocationRow(location: location)
                            }
                        }
                        .padding(.top, 5)
                    }
                    .padding(.horizontal, 15)
                }
            }
            .navigationDestination(for: Location.self) { location in
                MapView(latitude: location.latitude, longitude: location.longitude, locationName: location.name)
            }
        }
    }
}

// Location Model with Coordinates
struct Location: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let address: String
    let date: String
    let time: String
    let distance: String
    let latitude: Double
    let longitude: Double
}

// Map View to Show Selected Location
struct MapView: View {
    var latitude: Double
    var longitude: Double
    var locationName: String

    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack {
            Map(position: .constant(.region(
                MKCoordinateRegion(
                    center: CLLocationCoordinate2D(latitude: latitude, longitude: longitude),
                    span: MKCoordinateSpan(latitudeDelta: 0.05, longitudeDelta: 0.05)
                )
            ))) {
                Marker(locationName, coordinate: CLLocationCoordinate2D(latitude: latitude, longitude: longitude))
            }
            .edgesIgnoringSafeArea(.all)

            Button(action: {
                presentationMode.wrappedValue.dismiss()
            }) {
                Text("Back to Location History")
                    .font(.headline)
                    .padding()
                    .frame(maxWidth: .infinity)
                    .background(Color("Buttons").opacity(0.7))
                    .foregroundColor(.black)
                    .clipShape(RoundedRectangle(cornerRadius: 10))
                    .padding()
            }
        }
        .navigationBarBackButtonHidden(true)
    }
}

// Custom Row View
struct LocationRow: View {
    let location: Location

    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Image("pin")
                    .resizable()
                    .frame(width: 36, height: 35)

                Text(location.name)
                    .font(.headline)
                    .foregroundColor(Color("CustomBlue"))

                Spacer()

                Text("\(location.date) \(location.time)")
                    .font(.subheadline)
                    .foregroundColor(Color(red: 90/255, green: 90/255, blue: 90/255))
            }

            HStack {
                Text(location.address)
                    .font(.footnote)
                    .foregroundColor(.gray)

                Spacer()

                Text(location.distance)
                    .font(.footnote)
                    .foregroundColor(Color(red: 90/255, green: 90/255, blue: 90/255))
            }
            .padding(.top, 1)
        }
        .padding(9)
        .background(Color.white)
        .cornerRadius(10)
        .shadow(radius: 1)
    }
}

struct previews: PreviewProvider {
    static var previews: some View {
        LocationHistoryView()
    }
}
