//
//  Zone.swift
//  Atsight
//
//  Updated to fix iOS 17 deprecations
//

import SwiftUI
import MapKit
import FirebaseAuth
import FirebaseFirestore
// Setting up the user's coordinates to be in Riyadh by default
extension CLLocationCoordinate2D {
    static var userLocation: CLLocationCoordinate2D {
        return .init(latitude: 24.7136, longitude: 46.6753)
    }
}

// Setting up the zoom around the user's location
extension MKCoordinateRegion {
    static var userRegion: MKCoordinateRegion {
        return .init(center: .userLocation, latitudinalMeters: 5000, longitudinalMeters: 5000)
    }
}

// Zone struct: Defines the data structure for a geographical zone.
struct Zone: Identifiable {
    let id = UUID()
    var coordinate: CLLocationCoordinate2D
    var zoneName: String
    var isSafeZone: Bool
    var zoneSize: Double
}

struct AddZonePage: View {
    @Environment(\.presentationMode) var presentationMode
    
    // Define the camera's position
    @State private var cameraPosition = MapCameraPosition.region(MKCoordinateRegion.userRegion)
    
    // Temporary zone values that the user can adjust before saving
    @State private var tempZoneCoordinates = CLLocationCoordinate2D.userLocation
    @State private var tempZoneSize: Double = 50
    @State private var tempIsSafeZone = true
    @State private var tempZoneName = ""

    // Initializing zones list
    @State private var zones: [Zone] = []
    
    // Create a temporary zone for display
    var tempZone: Zone {
        return Zone(coordinate: tempZoneCoordinates, zoneName: "Your Location", isSafeZone: tempIsSafeZone, zoneSize: tempZoneSize)
    }
    
    var body: some View {
        ZStack {
            // Show both the saved zones and the temporary zone
            Map(position: $cameraPosition) {
                ForEach(zones + [tempZone]) { zone in
                    Annotation(zone.zoneName, coordinate: zone.coordinate) {
                        ZStack {
                            Circle()
                                .fill(zone.isSafeZone ? Color.green.opacity(0.3) : Color.red.opacity(0.3))
                                .frame(width: calculateZoneSize(zone.zoneSize), height: calculateZoneSize(zone.zoneSize))
                            Image(systemName: "mappin.circle.fill")
                                .foregroundColor(zone.id == tempZone.id ? .red : .black)
                                .font(.title)
                        }
                    }
                }
            }
            .gesture(
                LongPressGesture(minimumDuration: 0.5)
                    .sequenced(before: DragGesture(minimumDistance: 0))
                    .onEnded { value in
                        switch value {
                        case .second(true, let drag):
                            if let location = drag?.location {
                                let coordinate = convertToCoordinate(location: location)
                                tempZoneCoordinates = coordinate
                            }
                        default:
                            break
                        }
                    }
            )
            .ignoresSafeArea()
            
            VStack {
                Spacer()
                Color.clear
                    .frame(height: UIScreen.main.bounds.height / 4)
                    .cornerRadius(20)
                    .shadow(radius: 10)
                    .overlay(
                        VStack {
                            TextField("Enter your zone's name", text: $tempZoneName)
                                .padding(10)
                                .background(Color.white)
                                .cornerRadius(10)
                                .padding()
                            
                            HStack {
                                Button {
                                    tempIsSafeZone = true
                                } label: {
                                    Text("Safe").fontWeight(.bold)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(tempIsSafeZone ? Color.green : Color.gray.opacity(0.3))
                                        .foregroundColor(tempIsSafeZone ? .white : .black)
                                        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                }
                                .padding([.leading, .bottom])
                                
                                Button {
                                    tempIsSafeZone = false
                                } label: {
                                    Text("Unsafe").fontWeight(.bold)
                                        .frame(maxWidth: .infinity)
                                        .padding()
                                        .background(tempIsSafeZone ? Color.gray.opacity(0.3) : Color.red)
                                        .foregroundColor(tempIsSafeZone ? .black : .white)
                                        .clipShape(RoundedRectangle(cornerRadius: 10, style: .continuous))
                                }
                                .padding([.trailing, .bottom])
                            }
                            
                            Text("Zone size:")
                            Slider(value: $tempZoneSize, in: 1...200)
                                .accentColor(.black)
                                .padding([.horizontal, .bottom], 30)
                        }
                        .background(Color.mint.opacity(0.25))
                        .border(Color.green)
                        .cornerRadius(10)
                        .padding()
                    )
                
                Button {
                    addZone(coordinates: tempZoneCoordinates, size: tempZoneSize, isSafe: tempIsSafeZone, name: tempZoneName, zonesList: &zones)
                } label: {
                    Text("Add").fontWeight(.bold)
                }
                .frame(width: 100, height: 50)
                .background(Color.mint)
                .foregroundColor(.white)
                .cornerRadius(10)
                .padding()
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading:
            Button(action: { presentationMode.wrappedValue.dismiss() }) {
                HStack {
                    Image(systemName: "arrow.left")
                    Text("Back")
                }
            }
        )
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text("Add Zone")
                    .font(.system(size: 24, weight: .bold))
            }
            ToolbarItem(placement: .navigationBarTrailing) {
                NavigationLink(destination: SavedZonesView(zones: zones)) {
                    Text("Show Zones").fontWeight(.semibold).foregroundColor(.white).padding(7).background(Color.mint).cornerRadius(10)
                }
            }
        }
    }
    
    // Function to adjust the zone's circle size when zooming
    func calculateZoneSize(_ zoneSize: Double) -> CGFloat {
        let metersPerPoint = cameraPosition.region!.span.latitudeDelta * 111000
        let zoomFactor = CGFloat(metersPerPoint)
        let baseSize: CGFloat = CGFloat(zoneSize * 2)
        return baseSize / zoomFactor * 5000
    }
    
    // Function to add a zone
    func addZone(coordinates: CLLocationCoordinate2D, size: Double, isSafe: Bool, name: String, zonesList: inout [Zone]) {
        guard let user = Auth.auth().currentUser else {
            print("No user logged in")
            return
        }

        let db = Firestore.firestore()

        db.collection("guardians").whereField("uid", isEqualTo: user.uid).getDocuments { snapshot, error in
            if let error = error {
                print("Error fetching guardianID: \(error.localizedDescription)")
                return
            }

            guard let guardianDocument = snapshot?.documents.first else {
                print("No guardian found with this UID")
                return
            }

            let guardianID = guardianDocument.documentID
            let childID = "childID" // Replace with actual child ID

            let safezonesRef = db.collection("guardians").document(guardianID)
                .collection("children").document(childID)
                .collection("safezones").document()

            let zoneID = safezonesRef.documentID

            let newZoneData: [String: Any] = [
                "zoneID": zoneID,
                "zonename": name,
                "isSafe": isSafe,
                "locationCoordinate": [coordinates.latitude, coordinates.longitude],
                "zoneSize": size
            ]

            safezonesRef.setData(newZoneData) { error in
                if let error = error {
                    print("Error saving zone: \(error.localizedDescription)")
                } else {
                    print("Zone saved successfully!")

                    // Move zone update to the main thread
                    DispatchQueue.main.async {
                        let newZone = Zone(coordinate: coordinates, zoneName: name, isSafeZone: isSafe, zoneSize: size)
                        
                        // Instead of using `inout`, update the state variable directly
                        zones.append(newZone)
                    }
                }
            }
        }
    }

    
    // Convert tap location to coordinates
    func convertToCoordinate(location: CGPoint) -> CLLocationCoordinate2D {
        let mapSize = UIScreen.main.bounds.size
        let centerPoint = CGPoint(x: mapSize.width / 2, y: mapSize.height / 2)
        let xDelta = (location.x - centerPoint.x) / mapSize.width
        let yDelta = (location.y - centerPoint.y) / mapSize.height
        let latitudeDelta = cameraPosition.region!.span.latitudeDelta * Double(-yDelta)
        let longitudeDelta = cameraPosition.region!.span.longitudeDelta * Double(xDelta)
        let newLatitude = cameraPosition.region!.center.latitude + latitudeDelta
        let newLongitude = cameraPosition.region!.center.longitude + longitudeDelta
        return CLLocationCoordinate2D(latitude: newLatitude, longitude: newLongitude)
    }
}

// Saved Zones Page
struct SavedZonesView: View {
    @Environment(\.presentationMode) var presentationMode
    let zones: [Zone]
    
    var body: some View {
        List {
            ForEach(zones) { zone in
                HStack {
                    Image(systemName: "mappin")
                    Text(zone.zoneName)
                        .font(.title2)
                        .fontWeight(.semibold)
                    VStack(alignment: .leading) {
                        Text("\(zone.zoneName)")
                            .font(.title2)
                            .fontWeight(.semibold)
                        
                        Text("\(zone.coordinate.latitude), \(zone.coordinate.longitude)").foregroundColor(.gray)
                    }// end vstack

                    Spacer()
                    Text(zone.isSafeZone ? "Safe" : "Unsafe")
                        .foregroundColor(zone.isSafeZone ? .green : .red)
                        .padding(5)
                        .background(Color(zone.isSafeZone ? .green : .red).opacity(0.3))
                        .cornerRadius(10)
                }
            }
        }
        .navigationBarBackButtonHidden(true)
        .navigationBarItems(leading:
                                Button(action: { // navigate back
                self.presentationMode.wrappedValue.dismiss()
            }) {
                // navigate back button styling:
                HStack {
                    Image(systemName: "arrow.left")
                    Text("Back")
                }
            }
        )
        .toolbar {
            ToolbarItem(placement: .principal) {
                Text("safe/unsafe zones")
                    .font(.system(size: 24, weight: .bold))
            }
        } // end toolbar
    }
}
