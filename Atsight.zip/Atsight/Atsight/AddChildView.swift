import SwiftUI
import FirebaseAuth
import FirebaseFirestore

struct AddChildView: View {
    @Environment(\.presentationMode) var presentationMode
    @State private var name: String = ""
    @State private var age: String = ""
    @State private var isImagePickerPresented = false
    @State private var profileImage: UIImage? = nil
    
    let ages = Array(1...18).map { "\($0)" } // Age options from 1 to 18
    
    var body: some View {
        VStack {
            Button(action: {
                isImagePickerPresented.toggle()
            }) {
                if let profileImage = profileImage {
                    Image(uiImage: profileImage)
                        .resizable()
                        .scaledToFill()
                        .frame(width: 120, height: 120)
                        .clipShape(Circle())
                } else {
                    ZStack {
                        Circle()
                            .stroke(Color.gray, lineWidth: 1)
                            .frame(width: 120, height: 120)
                        VStack {
                            Image(systemName: "person.crop.circle")
                                .resizable()
                                .frame(width: 50, height: 50)
                                .foregroundColor(.gray)
                            Text("add picture")
                                .font(.caption)
                                .foregroundColor(.gray)
                        }
                    }
                }
            }
            .sheet(isPresented: $isImagePickerPresented) {
                ImagePicker(image: $profileImage)
            }
            
            VStack(alignment: .leading, spacing: 10) {
                Text("Name")
                    .font(.headline)
                TextField("Enter name", text: $name)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .padding(.bottom, 10)
                
                Text("Age")
                    .font(.headline)
                Picker("Select Age", selection: $age) {
                    ForEach(ages, id: \..self) { age in
                        Text(age).tag(age)
                    }
                }
                .pickerStyle(MenuPickerStyle())
                .frame(height: 50)
                .background(Color(.systemGray6))
                .cornerRadius(8)
            }
            .padding()
            
            Spacer()
            
            Button(action: {
                addChild()
            }) {
                Text("create")
                    .font(.headline)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(name.isEmpty || age.isEmpty ? Color.green.opacity(0.5) : Color.green)
                    .cornerRadius(10)
            }
            .disabled(name.isEmpty || age.isEmpty)
            .padding()
        }
        .padding()
        .navigationTitle("add child")
        .navigationBarTitleDisplayMode(.inline)
        .navigationBarBackButtonHidden(true)
        .toolbar {
            ToolbarItem(placement: .navigationBarLeading) {
                Button(action: {
                    presentationMode.wrappedValue.dismiss()
                }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.black)
                }
            }
        }
    }
    
    func addChild() {
        guard let uid = Auth.auth().currentUser?.uid else {
            print("No authenticated user")
            return
        }

        let db = Firestore.firestore()
        
        // Step 1: Fetch guardianID associated with the authenticated user
        db.collection("guardians").whereField("uid", isEqualTo: uid).getDocuments { snapshot, error in
            if let error = error {
                print("Error fetching guardianID: \(error.localizedDescription)")
                return
            }
            
            guard let document = snapshot?.documents.first else {
                print("No guardian found with this UID")
                return
            }
            
            let guardianID = document.documentID
            let childrenCollection = db.collection("guardians").document(guardianID).collection("children")
            
            // Step 2: Get the next child ID number
            childrenCollection.getDocuments { snapshot, error in
                if let error = error {
                    print("Error fetching children count: \(error.localizedDescription)")
                    return
                }
                
                let newChildID = (snapshot?.documents.count ?? 0) + 1 // Assign a sequential numeric ID
                let childRef = childrenCollection.document("\(newChildID)")
                
                let childData: [String: Any] = [
                    "childID": newChildID, // ✅ Store child ID as a number
                    "name": name,
                    "age": age
                ]
                
                // Step 3: Store child data
                childRef.setData(childData) { error in
                    if let error = error {
                        print("Failed to add child: \(error.localizedDescription)")
                    } else {
                        print("Child successfully added!")
                        
                        // ✅ Step 4: Create empty safezones & unsafezones collections
                        let safezonesRef = childRef.collection("safezones").document("default_safezone")
                        let unsafezonesRef = childRef.collection("unsafezones").document("default_unsafezone")
                        
                        let defaultSafezone: [String: Any] = [
                            "zoneID": "safe1",
                            "zonename": "Default Safe Zone",
                            "locationCoordinate": [0.0, 0.0],
                            "zonesize": "",
                            "issafe": true
                        ]
                        
                        let defaultUnsafezone: [String: Any] = [
                            "zoneID": "unsafe1",
                            "zonename": "Default Unsafe Zone",
                            "locationCoordinate": [0.0, 0.0],
                            "zonesize": "",
                            "issafe": false
                        ]
                        
                        // ✅ Create safe zone
                        safezonesRef.setData(defaultSafezone) { error in
                            if let error = error {
                                print("Error adding safe zone: \(error.localizedDescription)")
                            }
                        }
                        
                        // ✅ Create unsafe zone
                        unsafezonesRef.setData(defaultUnsafezone) { error in
                            if let error = error {
                                print("Error adding unsafe zone: \(error.localizedDescription)")
                            }
                        }
                        
                        // Close the add child view
                        presentationMode.wrappedValue.dismiss()
                    }
                }
            }
        }
    }

}

// Image Picker for Profile Picture Selection
struct ImagePicker: UIViewControllerRepresentable {
    @Binding var image: UIImage?
    
    class Coordinator: NSObject, UINavigationControllerDelegate, UIImagePickerControllerDelegate {
        var parent: ImagePicker
        
        init(parent: ImagePicker) {
            self.parent = parent
        }
        
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let selectedImage = info[.originalImage] as? UIImage {
                parent.image = selectedImage
            }
            picker.dismiss(animated: true)
        }
    }
    
    func makeCoordinator() -> Coordinator {
        Coordinator(parent: self)
    }
    
    func makeUIViewController(context: Context) -> UIImagePickerController {
        let picker = UIImagePickerController()
        picker.delegate = context.coordinator
        picker.sourceType = .photoLibrary
        return picker
    }
    
    func updateUIViewController(_ uiViewController: UIImagePickerController, context: Context) {}
}

struct AddChildView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            AddChildView()
        }
    }
}
