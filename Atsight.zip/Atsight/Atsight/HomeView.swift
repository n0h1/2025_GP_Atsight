import SwiftUI
import MapKit
import FirebaseAuth
import FirebaseFirestore

struct HomeView: View {
    @Binding var selectedChild: Child?
    @Binding var expandedChild: Child?
    @State private var firstName: String = "Guest" // Default if name isn't found
    @State private var isAddChildPresented = false // State for navigation

    var children = [
        Child(name: "sara", status: "On the math lesson", distance: 652, color: .green),
        Child(name: "leena", status: "On the school grounds", distance: 1826, color: .yellow),
        Child(name: "najd", status: "On the way home", distance: 82, color: .blue)
    ]

    var body: some View {
        NavigationStack {
            VStack(alignment: .leading) {
                HStack {
                    // Notification Bell Icon on the Left
                    Button(action: {
                            print("Notification button tapped")
                        }) {
                            Image(systemName: "bell")
                                .resizable()
                                .frame(width: 24, height: 24)
                                .padding(.leading, 22)
                        }
                        .buttonStyle(PlainButtonStyle())
                        .padding(.bottom, 60)
                    
                    Spacer()
                    
                    // Logo in the Center
                    Image("locationMarkLogo")
                        .resizable()
                        .frame(width: 120, height: 118)
                        .padding(.trailing,35)
                    
                    Spacer()
                }
                .frame(maxWidth: .infinity)
                .padding(.top)

                VStack(alignment: .leading, spacing: 20) {
                    // Greeting with User's First Name
                    Text("Hello \(firstName)")
                        .font(.largeTitle).bold()
                        .foregroundColor(Color("Blue"))
                        .padding(.top, 20)
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("View your kids' locations.")
                            .font(.title3)
                            .foregroundColor(.black)
                            .fontWeight(.medium)
                        
                        Text("Stay connected and informed about their well-being.")
                            .font(.body)
                            .foregroundColor(.gray)
                            .lineLimit(2)
                            .fixedSize(horizontal: false, vertical: true)
                    }
                    .padding(.bottom, 10)

                    // Add child section
                    HStack {
                        Button(action: {
                            isAddChildPresented = true // Navigate to AddChildView
                        }) {
                            Text("Add child")
                                .padding(.horizontal, 16)
                                .padding(.vertical, 10)
                                .foregroundColor(Color("Blue"))
                                .background(Color.white)
                                .cornerRadius(25)
                                .shadow(radius: 5)
                                .overlay(
                                    RoundedRectangle(cornerRadius: 25)
                                        .stroke(Color.gray, lineWidth: 1)
                                )
                        }
                    }
                    .padding(.leading,250)
                }
                .padding(.horizontal)

                ScrollView {
                    VStack(spacing: 15) {
                        ForEach(children) { child in
                            ChildCardView(child: child, expandedChild: $expandedChild)
                                .onTapGesture {
                                    withAnimation {
                                        expandedChild = child  // Expand the tapped child
                                        selectedChild = child  // Navigate to ChildLocationView
                                        print("Selected Child: \(child.name)") // Debugging log
                                    }
                                }
                                .padding(.top)
                        }
                    }
                }
                .padding(.top)
            }
            .onAppear {
                fetchUserName() // Fetch user's first name when HomeView appears
            }
            .fullScreenCover(item: $selectedChild) { child in
                ChildLocationView(child: child) // Navigates here on tap
            }
            .navigationDestination(isPresented: $isAddChildPresented) {
                AddChildView()
            }
        }
    }

    // ✅ Updated function to Fetch First Name from Firestore using guardianID
    func fetchUserName() {
        guard let uid = Auth.auth().currentUser?.uid else {
            print("No user logged in")
            return
        }

        let db = Firestore.firestore()
        
        // 🔎 Step 1: Find the guardian document where uid matches
        db.collection("guardians").whereField("uid", isEqualTo: uid).getDocuments { snapshot, error in
            if let error = error {
                print("Error fetching guardian ID: \(error.localizedDescription)")
                return
            }

            guard let document = snapshot?.documents.first else {
                print("No guardian found with this UID")
                return
            }

            let guardianID = document.documentID // ✅ This is now a number like "1", "2", "3"

            // 🔎 Step 2: Fetch FirstName using guardianID
            db.collection("guardians").document(guardianID).getDocument { document, error in
                if let document = document, document.exists {
                    if let fetchedFirstName = document.data()?["FirstName"] as? String {
                        firstName = fetchedFirstName
                    } else {
                        print("First name not found in document")
                    }
                } else {
                    print("User document not found")
                }
            }
        }
    }

}

#Preview {
    HomeView(selectedChild: .constant(nil), expandedChild: .constant(nil))
}
