//
//  SettingsView.swift
//  Atsight
//
//  Created by lona on 26/02/2025.
//

import SwiftUI

struct SettingsView: View {
    var body: some View {
        NavigationView {
            VStack {
                List {
                    Section(header: Text("Account").font(.headline)) {
                        SettingsRow(icon: "person", title: "Edit profile")
                        SettingsRow(icon: "shield", title: "Security")
                        SettingsRow(icon: "bell", title: "Notifications")
                        SettingsRow(icon: "lock", title: "Privacy")
                    }
                    
                    Section(header: Text("Support & About").font(.headline)) {
                        SettingsRow(icon: "questionmark.circle", title: "Help & Support")
                        SettingsRow(icon: "info.circle", title: "Terms and Policies")
                    }
                    
                    Section(header: Text("Appearance").font(.headline)) {
                        SettingsRow(icon: "moon.fill", title: "Dark Mode")
                    }
                }
                .listStyle(PlainListStyle())
                
                // Log Out Button
                Button(action: {
                    logOutUser()
                }) {
                    Text("Log Out")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.red)
                        .foregroundColor(.white)
                        .font(.headline)
                        .cornerRadius(10)
                        .padding(.horizontal, 20)
                }
                .padding(.bottom, 20)
            }
            .navigationTitle("Settings")
        }
    }
    
    // Log Out Function Placeholder
    func logOutUser() {
        print("User Logged Out") // Replace with actual Firebase log out logic
    }
}

struct SettingsRow: View {
    let icon: String
    let title: String
    
    var body: some View {
        HStack {
            Image(systemName: icon)
                .foregroundColor(.gray)
                .padding(.trailing, 10)
            Text(title)
                .font(.body)
            Spacer()
        }
        .padding()
        .background(Color(.systemBackground))
        .cornerRadius(10)
        .shadow(radius: 1)
    }
}

struct SettingsView_Previews: PreviewProvider {
    static var previews: some View {
        SettingsView()
    }
}
