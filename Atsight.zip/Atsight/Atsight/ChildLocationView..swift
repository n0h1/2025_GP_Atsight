//
//  ChildLocationView.swift
//  AtSightSprint0Test
//
//  Updated to fix iOS 17 deprecations
//

import SwiftUI
import MapKit

struct ChildLocationView: View {
    var child: Child
    @State private var position = MapCameraPosition.region(
        MKCoordinateRegion(
            center: CLLocationCoordinate2D(latitude: 24.7136, longitude: 46.6753),
            span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01)
        )
    )
    @State private var isMapExpanded = false
    @Environment(\.presentationMode) var presentationMode

    var body: some View {
        VStack(spacing: 0) {
            // Map View with Tap Gesture for Expansion
            ZStack {
                Map(position: $position) {
                    Annotation("Child Location", coordinate: position.region!.center) {
                        Image(systemName: "mappin.circle.fill")
                            .foregroundColor(.red)
                            .font(.title)
                    }
                }
                .frame(height: isMapExpanded ? 600 : 350)
                .cornerRadius(30)
                .padding(.horizontal)
                .animation(.spring(), value: isMapExpanded)
                .onTapGesture { isMapExpanded.toggle() }

                // Back Button
                Button(action: { presentationMode.wrappedValue.dismiss() }) {
                    Image(systemName: "chevron.left")
                        .foregroundColor(.black)
                        .font(.system(size: 20, weight: .bold))
                        .padding()
                        .cornerRadius(10)
                        .shadow(radius: 5)
                }
                .offset(x: -150, y: -130)

                // HALT Button
                Button(action: {
                    // Action for HALT button
                }) {
                    Text("HALT button")
                        .font(.footnote)
                        .padding(.horizontal, 15)
                        .padding(.vertical, 8)
                        .background(Color.red)
                        .foregroundColor(.white)
                        .cornerRadius(20)
                        .shadow(radius: 5)
                }
                .offset(x: 100, y: -100)
            }
            .padding(.bottom, isMapExpanded ? 0 : -40)

            // Profile Image and Card Section
            ZStack {
                VStack(spacing: 10) {
                    Image(systemName: "person.circle.fill")
                        .resizable()
                        .frame(width: 80, height: 80)
                        .foregroundColor(Color("Blue"))  // Fixed color conflict
                        .background(Circle().fill(Color.white))
                        .overlay(Circle().stroke(Color("CustomBlue"), lineWidth: 3))
                        .shadow(radius: 5)
                        .offset(y: 10)

                    Text("\(child.name)")
                        .font(.title2).bold()
                        .foregroundColor(Color("Blue"))
                        .padding(.top, 20)

                    Text("Located on the school")
                        .foregroundColor(.gray)

                    Divider().padding(.horizontal)

                    // Timeline Section
                    VStack(alignment: .leading, spacing: 20) {
                        TimelineItem(icon: "checkmark.circle.fill", color: .green, title: "House", time: "4:00 pm - 6:00 am")
                        TimelineItem(icon: "mappin.circle.fill", color: .green, title: "On way to school", time: "6:00 am - 6:30 am")
                        TimelineItem(icon: "number.circle.fill", color: .orange, title: "School", time: "6:30 am", number: "43")
                    }
                    .padding(.horizontal)
                    .padding(.bottom, 20)
                }
                .background(Color.white)
                .cornerRadius(30)
                .padding(.horizontal)
                .shadow(radius: 5)
            }

            Spacer()
        }
        .background(Color(UIColor.systemGroupedBackground).edgesIgnoringSafeArea(.all))
    }
}

// Timeline Item Component
struct TimelineItem: View {
    var icon: String
    var color: Color
    var title: String
    var time: String
    var number: String? = nil

    var body: some View {
        HStack {
            VStack {
                Image(systemName: icon)
                    .foregroundColor(color)
                    .font(.title3)
                    .background(Circle().fill(Color.white).shadow(radius: 2))
                Rectangle()
                    .frame(width: 2, height: 40)
                    .foregroundColor(color)
            }

            VStack(alignment: .leading, spacing: 5) {
                Text(title)
                    .font(.headline)
                Text(time)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
            Spacer()

            if let number = number {
                Text(number)
                    .font(.headline)
                    .foregroundColor(.orange)
                    .padding(8)
                    .background(Color.white)
                    .cornerRadius(15)
                    .shadow(radius: 2)
            }

            Image(systemName: "chevron.right")
                .foregroundColor(.gray)
        }
    }
}

#Preview {
    ContentView()
}
