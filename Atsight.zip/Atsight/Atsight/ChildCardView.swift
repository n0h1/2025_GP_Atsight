//
//  ChildCardView.swift
//  AtSightSprint0Test
//
//  Created by Najd Alsabi on 13/02/2025.
//

import SwiftUI

struct ChildCardView: View {
    var child: Child
    @Binding var expandedChild: Child?
    @State private var showEditProfile = false
    
    var body: some View {
        VStack(alignment: .leading) {
            HStack {
                Circle()
                    .frame(width: 50, height: 50)
                    .foregroundColor(child.color.opacity(0.3))
                VStack(alignment: .leading) {
                    Text(child.name).bold()
                    Text(child.status).foregroundColor(.gray)
                }
                Spacer()
                Button(action: {
                           showEditProfile = true
                       }) {
                           Image(systemName: "pencil")
                               .foregroundColor(Color("Blue"))
                               .padding(.trailing, 10)
                               .padding(.bottom, 30)
                       }
                       .sheet(isPresented: $showEditProfile) {
                           EditProfileView()
                       }
            }

            if expandedChild == child {
                Text("Distance: \(child.distance)m")
                    .font(.caption).foregroundColor(.gray)
                    .padding(.top, 5)
            }
        }
        .padding()
        .background(Color.white)
        .cornerRadius(20)
        .shadow(radius: 4)
        .padding(.horizontal)
    }
}



